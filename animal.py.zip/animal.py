class animal: 
    def __init__(self, name, makanan, hidup, berkembang_biak):
        self.name = name
        self.makanan = makanan
        self.hidup = hidup
        self.berkembang_biak = berkembang_biak

cetak = animal("Sapi", "Rumput", "Darat", "Melahirkan")
print (f"Nama Hewan : {cetak.name}")
print (f"Makanan : {cetak.makanan}")
print (f"Hidup : {cetak.hidup}")
print (f"Berkembang Biak : {cetak.berkembang_biak}")

print("############################################")

#ini subclass
class badak(animal):
#ini properti
    def __init__(self, name, makanan, hidup, berkembang_biak):
        super().__init__(name, makanan, hidup, berkembang_biak)
        self.name = name
        self.makanan = makanan
        self.hidup = hidup
        self.berkembang_biak = berkembang_biak
    def badak(self):
        print(f"Nama hewan ini adalah {self.name} makanannya adalah {self.makanan} hidupnya di {self.hidup} berkembang biak dengan {self.berkembang_biak}")

#ini subclass
class ikan(animal):
#ini properti
    def __init__(self, name, makanan, hidup, berkembang_biak):
        super().__init__(name, makanan, hidup, berkembang_biak)
        self.name = name
        self.makanan = makanan
        self.hidup = hidup
        self.berkembang_biak = berkembang_biak
    def ikan(self):
        print(f"Nama hewan ini adalah {self.name} makanannya adalah {self.makanan} hidupnya di {self.hidup} berkembang biak dengan {self.berkembang_biak}")

#ini subclass
class ular(animal):
#ini properti
    def __init__(self, name, makanan, hidup, berkembang_biak):
        super().__init__(name, makanan, hidup, berkembang_biak)
        self.name = name
        self.makanan = makanan
        self.hidup = hidup
        self.berkembang_biak = berkembang_biak
    def ular(self):
        print(f"Nama hewan ini adalah {self.name} makanannya adalah {self.makanan} hidupnya di {self.hidup} berkembang biak dengan {self.berkembang_biak}")       
    
#cetak
animal1 = badak("badak", "dedaunan", "darat", "melahirkan")
animal1.badak()
animal2 = ikan("ikan", "pelet", "air", "bertelur")
animal2.ikan()
animal3 = ular("ular", "daging", "darat dan air", "bertelur")
animal3.ular()
    

